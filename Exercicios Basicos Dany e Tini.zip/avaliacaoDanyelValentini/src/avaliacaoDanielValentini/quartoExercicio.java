package avaliacaoDanielValentini;

import java.util.Scanner;

public class quartoExercicio {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o nome");
		String nome = entrada.nextLine();
		
		int salario = 1045;
		double salarioFinal  = salario + (salario/2);
		System.out.println("o salario de "+nome+ " � de "+ salarioFinal);
	}
	
}


 