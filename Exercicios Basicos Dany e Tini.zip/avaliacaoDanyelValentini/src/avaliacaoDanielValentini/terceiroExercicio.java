package avaliacaoDanielValentini;

import java.text.DecimalFormat;
import java.util.Scanner;

public class terceiroExercicio {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		System.out.println("Digite o valor da coca-cola: ");
		double coca = entrada.nextDouble();
		double CocaNova = ((coca * 100) / 110) + coca;

		System.out.println("Digite o valor da �gua mineral: ");
		double agua = entrada.nextDouble();
		double aguaNova = ((agua * 100) / 50) + agua;

		System.out.println("Digite o valor da Brahma: ");
		double cerveja = entrada.nextDouble();
		double cervejaNova = ((cerveja * 100) / 80) + cerveja;

		DecimalFormat df = new DecimalFormat("##.##");
		System.out.println("O novo valor da coca � de: R$" + df.format(CocaNova));

		System.out.println("O novo valor da �gua � de: R$" + df.format(aguaNova));

		System.out.println("O novo valor da Brahma � de: R$" + df.format(cervejaNova));

	}

}
