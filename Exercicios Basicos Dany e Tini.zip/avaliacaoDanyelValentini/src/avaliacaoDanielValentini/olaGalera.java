package avaliacaoDanielValentini;

public class olaGalera {
	public static void main(String[] args) {
		System.out.println("Ol� galera do curso de Java");
	}
	
}
