package avaliacaoDanielValentini;

import java.text.DecimalFormat;
import java.util.Scanner;

public class segundoExercicio {


    public static void main(String[] args) {

        Scanner entrada = new Scanner (System.in);

        System.out.println("Digite o primeiro valor: ");
        double preco1 = entrada.nextDouble();

        System.out.println("Digite o segundo valor: ");
        double preco2 = entrada.nextDouble();

        System.out.println("Digite o terceiro valor: ");
        double preco3 = entrada.nextDouble();

        double media = (preco1 + preco2 + preco3) / 3;

        DecimalFormat df = new  DecimalFormat("##.##");

        System.out.println("A media do valor vendido � de: R$" + df.format(media));



        }
    }