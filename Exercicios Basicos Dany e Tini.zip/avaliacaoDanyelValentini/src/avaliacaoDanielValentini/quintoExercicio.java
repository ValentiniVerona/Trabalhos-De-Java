package avaliacaoDanielValentini;

import java.util.Scanner;

public class quintoExercicio {

  public static void main(String[] args) {
    
  Scanner entrada = new Scanner(System.in);
  double pi = 3.14;
  double formula = 0;
    
  System.out.println("Calculadora de Raio \n");
  
  System.out.println("Infome o valor do raio:");
  double raio = entrada.nextDouble();
  double resultadoRaio = (raio * raio) * pi;
  
  System.out.println("Deseja visualizar a formula?");
  System.out.println("1 para SIM");
  System.out.println("2 para N�O");
  formula = entrada.nextInt();
  
  if(formula == 1) {
    System.out.println("\nA formula �: " + raio + "�" + " * " + pi);

  }
  
  System.out.printf("\nA �rea da circunf�rencia � de: " + resultadoRaio + " cm�");
  
  entrada.close();

   }

}