package model;

import java.util.Scanner;

import controller.ControleCliente;
import controller.ControleFuncionario;
import controller.ControleProdutos;
import controller.ControleVendas;

public class Main {
	public static void main(String[] args) {
		int option = 0;
		int optionSubMenu = 0;
		ControleCliente controleCliente = new ControleCliente();
		ControleFuncionario controleFuncionario = new ControleFuncionario();
		ControleProdutos controleProdutos = new ControleProdutos();
		ControleVendas controleVendas = new ControleVendas();

		Scanner ler = new Scanner(System.in);
		do {
			System.out.println("____________MENU____________ \n");
			System.out.println("Digite a op��o referente ao menu que deseja abrir:");
			System.out.printf("\n [1] Cliente \n [2] Funcion�rio \n [3] Produto \n [4] Vendas \n [5] Sair \n");
			option = ler.nextInt();
			switch (option) {
			case 1: {

				System.out.printf(
						"\n [1] Adicionar Cliente \n [2] Remover Cliente \n [3] Alterar Cliente \n [4] Listar Clientes \n [5] Sair \n");
				optionSubMenu = ler.nextInt();
				switch (optionSubMenu) {
				case 1: {
					controleCliente.adicionar();
					break;
				}
				case 2: {
					controleCliente.excluir();
					break;
				}
				case 3: {
					controleCliente.alterar();
					break;
				}
				case 4: {

					controleCliente.listar();

					break;
				}

				}
				break;
			}
			case 2: {
				System.out.printf(
						"\n [1] Adicionar Funcionario \n [2] Remover Funcionario \n [3] Listar Funcionario \n [4] Alterar Funcionarios \n [5] Sair \n");
				optionSubMenu = ler.nextInt();
				switch (optionSubMenu) {

				case 1: {
					controleFuncionario.adicionar();
					break;
				}
				case 2: {
					controleFuncionario.excluir();
					break;
				}
				case 3: {
					controleFuncionario.listar();
					break;
				}
				case 4: {
					controleFuncionario.alterar();
					break;
				}
				}
				break;
			}
			case 3: {
				System.out.printf(
						"\n [1] Adicionar Produto \n [2] Remover Produto \n [3] Listar Produto \n [4] Alterar Produto \n [5] Sair \n");
				optionSubMenu = ler.nextInt();
				switch (optionSubMenu) {
				case 1: {
					controleProdutos.adicionar();
					break;
				}
				case 2: {
					controleProdutos.excluir();
					break;
				}
				case 3: {
					controleProdutos.listar();
					break;
				}
				case 4: {
					controleProdutos.alterar();
					break;
				}
				}
				break;
			}
			case 4: {
				System.out.printf(
						"\n [1] Adicionar Venda \n [2] Remover Venda \n [3] Listar Vendas \n [4] Alterar Venda \n [5] Sair \n");
				optionSubMenu = ler.nextInt();
				switch (optionSubMenu) {
				case 1: {
					controleVendas.adicionar();
					break;
				}
				case 2: {
					controleVendas.excluir();
					break;
				}
				case 3: {
					controleVendas.listar();
					break;
				}
				case 4: {
					controleVendas.alterar();
					break;
				}
				}
			}
			}

		} while (option != 5);
	}
}
