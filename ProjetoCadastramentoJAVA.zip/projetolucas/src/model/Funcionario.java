package model;

public class Funcionario extends Pessoa {
	private String salario;
	private String horario;
	private String cargo;
	private String gerente;
	private Integer codigo;
	
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	
	public Funcionario() {
		
	}
	public Funcionario(String nome, String cpf, String endereco, String salario, String horario, String cargo, String gerente, Integer codigo) {
		super(nome, cpf, endereco);
		this.salario = salario;
		this.horario = horario;
		this.cargo = cargo;
		this.gerente = gerente;	
		this.codigo = codigo;
	}

	public String getSalario() {
		return salario;
	}

	public void setSalario(String salario) {
		this.salario = salario;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getGerente() {
		return gerente;
	}

	public void setGerente(String gerente) {
		this.gerente = gerente;
	}

}
