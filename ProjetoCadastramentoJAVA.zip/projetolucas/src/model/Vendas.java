package model;

import java.util.ArrayList;
import java.util.List;

public class Vendas {
	private List <Produto> listaProduto= new ArrayList<>();
	private Integer codigoVenda;
	private String dataVenda;
	private String vendedor;
	private String mensalidade;
	private String planoVendido;
	
	public Vendas(List<Produto> listaProduto, String dataVenda, String vendedor, String mensalidade, String planoVendido, Integer codigoVenda) {
		this.listaProduto = listaProduto;
		this.dataVenda = dataVenda;
		this.vendedor = vendedor;
		this.mensalidade = mensalidade;
		this.planoVendido = planoVendido;
		this.codigoVenda = codigoVenda;
	}
	public Integer getCodigoVenda() {
		return codigoVenda;
	}
	public void setCodigoVenda(Integer codigoVenda) {
		this.codigoVenda = codigoVenda;
	}
	public Vendas() {
		
	}
	public String getPlanoVendido() {
		return planoVendido;
	}
	public void setPlanoVendido(String planoVendido) {
		this.planoVendido = planoVendido;
	}
	public List<Produto> getListaProduto() {
		return listaProduto;
	}
	public void setListaProduto(List<Produto> listaProduto) {
		this.listaProduto = listaProduto;
	}
	public String getDataVenda() {
		return dataVenda;
	}
	public void setDataVenda(String dataVenda) {
		this.dataVenda = dataVenda;
	}
	public String getVendedor() {
		return vendedor;
	}
	public void setVendedor(String vendedor) {
		this.vendedor = vendedor;
	}
	public String getMensalidade() {
		return mensalidade;
	}
	public void setMensalidade(String mensalidade) {
		this.mensalidade = mensalidade;
	} 
	
	
}
