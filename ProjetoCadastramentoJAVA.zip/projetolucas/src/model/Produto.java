package model;

public class Produto {
	private String nome;
	private Integer patrimonio;
	private String preco;
	private String marca;
	public Produto() {
		
	}
	
	public Produto (String nome, Integer patrimonio, String preco, String marca) { 
		this.nome = nome;
		this.patrimonio = patrimonio;
		this.marca = marca;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getPatrimonio() {
		return patrimonio;
	}

	public void setPatrimonio(Integer patrimonio) {
		this.patrimonio = patrimonio;
	}

	public String getPreco() {
		return preco;
	}

	public void setPreco(String preco) {
		this.preco = preco;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "Produto [nome=" + nome + ", patrimonio=" + patrimonio + ", preco=" + preco + ", marca=" + marca + "]";
	}
	
}
		

