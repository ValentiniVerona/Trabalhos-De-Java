package model;

public class Cliente extends Pessoa {
	private Integer codigoCliente = 1;
	private String planoCliente;
	private String numeroCliente;
	
	
	public Cliente() {
	
	}
	
	public Cliente(String nome, String cpf, String endereco, Integer codigoCliente, String planoCliente, String numeroCliente) {
		super(nome, cpf, endereco);
		this.codigoCliente = codigoCliente;
		this.planoCliente = planoCliente;
		this.numeroCliente = numeroCliente;
	}
	public Integer gerarCodigo() {
		return codigoCliente++;
	}
	
	public Integer getCodigoCliente() {
		return codigoCliente;
	}

	public void setCodigoCliente(Integer codigoCliente) {
		this.codigoCliente = codigoCliente;
	}

	public String getPlanoCliente() {
		return planoCliente;
	}
	public void setPlanoCliente(String planoCliente) {
		this.planoCliente = planoCliente;
	}	
	public String getNumeroCliente() {
		return numeroCliente;
	}
	public void setNumeroCliente(String numeroCliente) {
		this.numeroCliente = numeroCliente;
	}
}

