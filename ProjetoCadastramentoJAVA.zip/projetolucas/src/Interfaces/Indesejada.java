package Interfaces;

public interface Indesejada {
void adicionar();
void excluir();
void listar();
void alterar();

}
	