package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Interfaces.Indesejada;
import model.Cliente;
import model.Produto;

public class ControleCliente implements Indesejada {
	static List<Cliente> listaClientes = new ArrayList<>();
	Scanner ler = new Scanner(System.in);

	@Override
	public void adicionar() {
		Cliente cliente = new Cliente();
		System.out.println("Digite seu nome:");
		cliente.setNome(ler.nextLine());
		System.out.println("Digite seu CPF:");
		cliente.setCpf(ler.nextLine());
		System.out.println("Digite seu endere�o:");
		cliente.setEndereco(ler.nextLine());
		cliente.setCodigoCliente(cliente.gerarCodigo());
		listaClientes.add(cliente);
		System.out.println("Cliente foi cadastrado com sucesso!");
	}
	@Override
	public void excluir() {

		System.out.println("Digite o c�digo  do cliente que deseja excluir");
		int codigo = ler.nextInt();
		Cliente cliente = new Cliente();
		for (int i = 0; i < listaClientes.size(); i++) {
			cliente = listaClientes.get(i);
			if (cliente.getCodigoCliente() == codigo) {
				listaClientes.remove(i);
				System.out.println("Cliente Excluido com sucesso");
			}
		}
		
	}
	@Override
	public void listar() {
		
		for (Cliente cliente : listaClientes) {
			System.out.println("______________");
			System.out.println(cliente.getCodigoCliente());
			System.out.println(cliente.getNome());
			System.out.println(cliente.getCpf());
			System.out.println(cliente.getEndereco());
			System.out.println(cliente.getPlanoCliente());
			System.out.println("______________");
		}
	}
	@Override
	public void alterar() {
		System.out.println("Digite o c�digo  do cliente que deseja alterar");
		int codigo = ler.nextInt();
		ler.nextLine();
		for (Cliente clientes : listaClientes) {
			if (codigo == clientes.getCodigoCliente()) {
				Cliente cliente = new Cliente();
				System.out.println("Digite seu nome:");
				cliente.setNome(ler.nextLine());
				System.out.println("Digite seu CPF:");
				cliente.setCpf(ler.nextLine());
				System.out.println("Digite seu endere�o:");
				cliente.setEndereco(ler.nextLine());
				listaClientes.set(codigo-1, cliente);
				System.out.println("Cliente foi alterado com sucesso!");
			}
		}
	}

}
