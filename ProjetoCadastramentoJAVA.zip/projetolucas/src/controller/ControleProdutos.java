package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Interfaces.Indesejada;
import model.Produto;

public class ControleProdutos implements Indesejada {
	static List<Produto> listaProdutos = new ArrayList<>();
	Scanner ler = new Scanner(System.in);

	@Override
	public void adicionar() {
		Produto produto = new Produto();
		System.out.println("Digite o nome do produto:");
		produto.setNome(ler.nextLine());
		System.out.println("Digite o pre�o do produto:");
		produto.setPreco(ler.nextLine());
		System.out.println("Digite a marca do produto:");
		produto.setMarca(ler.nextLine());
		System.out.println("Digite o patrim�nio do produto:");
		produto.setPatrimonio(ler.nextInt());
		listaProdutos.add(produto);

	}
	@Override
	public void excluir() {

		System.out.println("Digite o c�digo  do produto que deseja excluir");
		int codigo = ler.nextInt();
		Produto produto= new Produto();
		for (int i = 0; i < listaProdutos.size(); i++) {
			produto = listaProdutos.get(i);
			if (produto.getPatrimonio() == codigo) {
				listaProdutos.remove(i);
			}
		}
	}
	@Override
	public void listar() {
		
		for (Produto produto : listaProdutos) {
			System.out.println("______________");
			System.out.println(produto.getPatrimonio());
			System.out.println(produto.getNome());
			System.out.println(produto.getPreco());
			System.out.println(produto.getMarca());
			System.out.println("______________");
		}
	}
	@Override
	public void alterar() {
		System.out.println("Digite o c�digo  do produto que deseja alterar");
		int patrimonio = ler.nextInt();
		ler.nextLine();
		for (Produto produtos : listaProdutos) {
			if (patrimonio == produtos.getPatrimonio()) {
				Produto produto = new Produto();
				System.out.println("Digite seu nome:");
				produto.setNome(ler.nextLine());
				System.out.println("Digite seu CPF:");
				produto.setPreco(ler.nextLine());
				System.out.println("Digite seu endere�o:");
				produto.setMarca(ler.nextLine());
				listaProdutos.set(listaProdutos.indexOf(produtos), produto);
			}
		}
	}

}
