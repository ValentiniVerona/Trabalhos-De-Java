package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Interfaces.Indesejada;
import model.Produto;
import model.Vendas;

public class ControleVendas implements Indesejada {
	static List<Vendas> listaVendas = new ArrayList<>();

	Scanner ler = new Scanner(System.in);

	@Override
	public void adicionar() {
		Vendas vendas = new Vendas();
		System.out.println("Digite o codigo da venda:");
		vendas.setCodigoVenda(ler.nextInt());
		ler.nextLine();

		Produto produto = new Produto();
		System.out.println("Digite o codigo do produto:");
		int codigo_produto = ler.nextInt();
		for (int i = 0; i < ControleProdutos.listaProdutos.size(); i++) {
			produto = ControleProdutos.listaProdutos.get(i);
			if (produto.getPatrimonio() == codigo_produto) {
				vendas.getListaProduto().add(produto);
			}

		}
		ler.nextLine();
		System.out.println("Digite o dia da venda");
		vendas.setDataVenda(ler.nextLine());
		System.out.println("Digite a mensalidade da venda:");
		vendas.setMensalidade(ler.nextLine());
		System.out.println("Digite quem foi o vendedor");
		vendas.setVendedor(ler.nextLine());
		System.out.println("Digite a quantia de megas do plano Vendido:");
		vendas.setPlanoVendido(ler.nextLine());
		listaVendas.add(vendas);
		System.out.println("Cadastrado com sucesso");


	}

	@Override
	public void excluir() {

		System.out.println("Digite o c�digo  do produto que deseja excluir");
		int codigo = ler.nextInt();
		Vendas produto = new Vendas();
		for (int i = 0; i < listaVendas.size(); i++) {
			produto = listaVendas.get(i);
			if (produto.getCodigoVenda() == codigo) {
				listaVendas.remove(i);
				System.out.println("Removido com sucesso");

			}
		}
	}

	@Override
	public void listar() {

		for (Vendas vendas : listaVendas) {
			System.out.println("______________");
			System.out.println(vendas.getCodigoVenda());
			System.out.println(vendas.getDataVenda());
			System.out.println(vendas.getMensalidade());
			System.out.println(vendas.getVendedor());
			System.out.println(vendas.getPlanoVendido());
			System.out.println("______________");
			
		}
	}

	@Override
	public void alterar() {
		System.out.println("Digite o c�digo  da venda que deseja alterar");
		int patrimonio = ler.nextInt();
		ler.nextLine();
		for (Vendas objeto : listaVendas) {
			if (patrimonio == objeto.getCodigoVenda()) {
				Vendas venda = new Vendas();
				System.out.println("Digite o codigo da venda:");
				venda.setCodigoVenda(ler.nextInt());
				ler.nextLine();
				System.out.println("Digite o dia da venda");
				venda.setDataVenda(ler.nextLine());
				System.out.println("Digite a mensalidade da venda:");
				venda.setMensalidade(ler.nextLine());
				System.out.println("Digite quem foi o vendedor");
				venda.setVendedor(ler.nextLine());
				System.out.println("Digite a quantia de megas do plano Vendido:");
				venda.setPlanoVendido(ler.nextLine());
				listaVendas.set(listaVendas.indexOf(objeto), venda);
				System.out.println("Alterado com sucesso");
			}
		}
	}

}
