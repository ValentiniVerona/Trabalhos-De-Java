package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Interfaces.Indesejada;
import model.Cliente;
import model.Funcionario;
import model.Produto;

public class ControleFuncionario implements Indesejada {
	static List<Funcionario> listaFuncionario = new ArrayList<>();
	Scanner ler = new Scanner(System.in);

	public void adicionar() {
		Funcionario funcionario = new Funcionario();
		System.out.println("Digite o codigo do funcionario:");
		funcionario.setCodigo(ler.nextInt());
		ler.nextLine();
		System.out.println("Digite o nome do funcionario:");
		funcionario.setNome(ler.nextLine());
		System.out.println("Digite o CPF:");
		funcionario.setCpf(ler.nextLine());
		System.out.println("Digite o endere�o:");
		funcionario.setEndereco(ler.nextLine());
		System.out.println("Digite o salario:");
		funcionario.setSalario(ler.nextLine());
		System.out.println("Digite o cargo:");
		funcionario.setCargo(ler.nextLine());
		System.out.println("Digite o gerente:");
		funcionario.setGerente(ler.nextLine());
		System.out.println("Digite o horario:");
		funcionario.setHorario(ler.nextLine());
		listaFuncionario.add(funcionario);

	}

	public void excluir() {
		System.out.println("Digite o c�digo  do funcionario que deseja excluir");
		int codigo = ler.nextInt();
		Funcionario funcionario = new Funcionario();
		for (int i = 0; i < listaFuncionario.size(); i++) {
			funcionario = listaFuncionario.get(i);
			if (funcionario.getCodigo() == codigo) {
				listaFuncionario.remove(i);
			}
		}

	}

	public void listar() {
		for (Funcionario funcionario : listaFuncionario) {
			System.out.println("______________");
			System.out.println(funcionario.getNome());
			System.out.println(funcionario.getCpf());
			System.out.println(funcionario.getEndereco());
			System.out.println(funcionario.getGerente());
			System.out.println(funcionario.getHorario());
			System.out.println(funcionario.getSalario());
			System.out.println("______________");
		}
	}

	public void alterar() {
		System.out.println("Digite o c�digo  do cliente que deseja alterar");
		int codigo = ler.nextInt();
		ler.nextLine();
		for (Funcionario funcionario : listaFuncionario) {
			if (codigo == funcionario.getCodigo()) {
				System.out.println("Digite seu nome:");
				funcionario.setNome(ler.nextLine());
				System.out.println("Digite seu CPF:");
				funcionario.setCpf(ler.nextLine());
				System.out.println("Digite seu endere�o:");
				funcionario.setEndereco(ler.nextLine());
				listaFuncionario.set(codigo - 1, funcionario);
			}
		}
	}
}